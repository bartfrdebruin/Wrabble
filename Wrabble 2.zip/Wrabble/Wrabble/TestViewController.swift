//
//  TestViewController.swift
//  Wrabble
//
//  Created by Eyolph on 11/01/16.
//  Copyright © 2016 Wrabble. All rights reserved.
//

import UIKit
import Parse

class TestViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
